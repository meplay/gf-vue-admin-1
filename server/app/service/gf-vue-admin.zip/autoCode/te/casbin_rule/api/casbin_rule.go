package v1

import (
	"fmt"
	"server/app/api/request"
	"server/app/api/response"
	"server/app/service"
	"server/library/global"
	"github.com/gogf/gf/frame/g"
	"github.com/gogf/gf/net/ghttp"
)

// CreateCasbinRule Create CasbinRule
// CreateCasbinRule 创建CasbinRule
func CreateCasbinRule(r *ghttp.Request) {
	var create request.CreateCasbinRule
	if err := r.Parse(&create); err != nil {
		global.FailWithMessage(r, err.Error())
		r.Exit()
	}
	if err := service.CreateCasbinRule(&create); err != nil {
		global.FailWithMessage(r, fmt.Sprintf("创建失败，%v", err))
		r.Exit()
	}
	global.OkWithMessage(r, "创建成功")
}

// DeleteCasbinRule Delete CasbinRule
// DeleteCasbinRule 删除CasbinRule
func DeleteCasbinRule(r *ghttp.Request) {
	var delete request.DeleteCasbinRule
	if err := r.Parse(&delete); err != nil {
		global.FailWithMessage(r, err.Error())
		r.Exit()
	}
	if err := service.DeleteCasbinRule(&delete); err != nil {
		global.FailWithMessage(r, fmt.Sprintf("删除失败，%v", err))
		r.Exit()
	}
	global.OkWithMessage(r, "删除成功")
}

// DeleteCasbinRules Batch delete CasbinRule
// DeleteCasbinRules 批量删除CasbinRule
func DeleteCasbinRules(r *ghttp.Request) {
	var deletes request.DeleteCasbinRules
	if err := r.Parse(&deletes; err != nil {
		global.FailWithMessage(r, err.Error())
		r.Exit()
	}
	if err := service.DeleteCasbinRules(&deletes); err != nil {
		global.FailWithMessage(r, fmt.Sprintf("批量删除失败，%v", err))
		r.Exit()
	}
	global.OkWithMessage(r, "批量删除成功")
}

// UpdateCasbinRule Update CasbinRule
// UpdateCasbinRule 更新CasbinRule
func UpdateCasbinRule(r *ghttp.Request) {
	var update request.UpdateCasbinRule
	if err := r.Parse(&update); err != nil {
		global.FailWithMessage(r, err.Error())
		r.Exit()
	}
	if err := service.UpdateCasbinRule(&update); err != nil {
		global.FailWithMessage(r, fmt.Sprintf("更新失败，%v", err))
		r.Exit()
	}
	global.OkWithMessage(r, "更新成功")
}

// FindCasbinRule Query CasbinRule with id
// FindCasbinRule 用id查询CasbinRule
func FindCasbinRule(r *ghttp.Request) {
	var find request.UpdateCasbinRule
	if err := r.Parse(&find); err != nil {
		global.FailWithMessage(r, err.Error())
		r.Exit()
	}
	if err := service.UpdateCasbinRule(&find); err != nil {
		global.FailWithMessage(r, fmt.Sprintf("获取失败，%v", err))
		r.Exit()
	}
	global.OkWithMessage(r, "获取成功")
}

// GetCasbinRuleList Page out the CasbinRule list
// GetCasbinRuleList 分页获取CasbinRule列表
func GetCasbinRuleList(r *ghttp.Request) {
	var pageInfo request.GetCasbinRuleList
	if err := r.Parse(&pageInfo); err != nil {
		global.FailWithMessage(r, err.Error())
		r.Exit()
	}
	list, total, err := service.GetCasbinRuleList(&pageInfo, condition)
	if err != nil {
		global.FailWithMessage(r, fmt.Sprintf("获取数据失败，%v", err))
		r.Exit()
	}
	global.OkWithData(r, response.PageResult{
		List:     list,
		Total:    total,
		Page:     pageInfo.Page,
		PageSize: pageInfo.PageSize,
	})
}
